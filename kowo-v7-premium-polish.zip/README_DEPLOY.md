# KOWO V7 Premium Polish

Version construite à partir de la base fonctionnelle fournie.

## À remplacer en priorité
- `index.html`
- `assets/v7-premium.css`
- `assets/v7-premium.js`
- `legal/mentions.html`
- `legal/mentions-legales.html`
- `legal/cgu.html`
- `legal/privacy.html`
- `legal/confidentialite.html`

## Positionnement
KOWO is the trusted infrastructure for community finance.

## Mention juridique intégrée
KOWO est présenté comme un produit logiciel conçu et actuellement distribué par YandaTech EI, avec KOWO SARL au Bénin portant la structuration locale, les partenariats institutionnels et le développement commercial.
